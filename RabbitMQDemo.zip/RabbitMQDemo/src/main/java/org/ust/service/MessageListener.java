package org.ust.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Service;
import org.ust.model.Message;

@Service
@RabbitListener(queues = {"${rabbitmq.queue.direct}"})
public class MessageListener {

    @RabbitListener(queues = "${rabbitmq.queue.direct}")
    public void receiveDirectMessage(Message message) {
        System.out.println("Received direct message: " + message);
    }


    private static final Logger logger = LoggerFactory.getLogger(MessageListener.class);

    @RabbitHandler
    public void handleMessage(Message message) {
        logger.info("Received message: {}", message);
        System.out.println("Received message: " + message);  // Adding both logging methods
    }
}
