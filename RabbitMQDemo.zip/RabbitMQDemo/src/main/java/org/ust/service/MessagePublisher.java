package org.ust.service;


import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.ust.model.Message;

import java.time.LocalDateTime;
import java.util.UUID;

@Service
public class MessagePublisher {

    private final RabbitTemplate rabbitTemplate;

    @Value("${rabbitmq.exchange.direct}")
    private String directExchange;


    @Value("${rabbitmq.routingkey.direct}")
    private String directRoutingKey;

    public MessagePublisher(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    public void sendDirectMessage(String content) {
        Message message = new Message(
                UUID.randomUUID().toString(),
                content,
                LocalDateTime.now().toString()
        );
        rabbitTemplate.convertAndSend(directExchange, directRoutingKey, message);
    }


}

