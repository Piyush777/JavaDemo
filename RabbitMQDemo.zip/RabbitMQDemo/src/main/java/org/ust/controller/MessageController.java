package org.ust.controller;

import org.springframework.amqp.core.MessageListener;
import org.springframework.web.bind.annotation.*;
import org.ust.service.MessagePublisher;

@RestController
@RequestMapping("/api/messages")
public class MessageController {

    private final MessagePublisher messagePublisher;

    public MessageController(MessagePublisher messagePublisher) {
        this.messagePublisher = messagePublisher;
    }

    @PostMapping("/direct")
    public String sendDirectMessage(@RequestBody String message) {
        messagePublisher.sendDirectMessage(message);
        return "Direct message sent successfully";
    }


}